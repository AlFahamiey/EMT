﻿# Nur Muhammad Al Fahamiey_23030630058_Exercise
Soal latihan EMT materi aljabar disertai latex


# R.2

No 50


Sederhanakan


$$\left(\frac{{125p^{12}q^{-14}r^{22}}}{{25p^8q^6r^{-15}}}\right)^{-4}$$\>$&(((125\*p^12\*q^-14\*r^22)/(25\*p^8\*q^6\*r^-15))^-4)


$$\frac{q^{80}}{625\,p^{16}\,r^{148}}$$dapat kita peroleh hasil yang lebih sederhana setelah kita operasiakan


No 90


Hitung


$$\frac{2^6 \cdot 2^{-3}}{2^{10} \cdot 2^{-8}}$$\>$&((2^6\*2^-3)/2^10/2^-8)


$$2$$dengan operasi penyelesaian sifat pangkat dapat kita peroleh hasilnya
2


No 91


Hitung


$$\frac{4(8 - 6)^2 - 4 \cdot 3 + 2 \cdot 8}{3^1 + 19^0}$$\>$&((4\*(8-6)^2-4\*3+2\*8)/3^1+10^0)


$$\frac{23}{3}$$kita bisa memperoleh bentuk sederhana setelah mengoperasikannya


No 104


Sederhanakan


$$\left( m^{x - b} \cdot n^{x + b} \right)^x \left( m^b \cdot n^{-b} \right)^x$$\>$&(m^x-b\*n^x+b)^x(m^b\*n^-b)^x


$$\left(-b\,n^{x}+m^{x}+b\right)^{x^{x}\left(\frac{m^{b}}{n^{b}}  \right)}$$kita bisa memperoleh bentuk sederhana setelah mengoperasikannya


No 105


Sederhanakan


$$\left[\frac{{(3x^a y^b)^3}}{{(-3x^a y^b)^2}}\right]^2$$\>$&(((3\*x^a\*y^b)^3)/(((-3\*x^a\*y^b)^2)^2))


$$\frac{1}{3\,x^{a}\,y^{b}}$$kita bisa memperoleh bentuk sederhana setelah mengoperasikannya


# R.3 No 20

$$\left(z-1\right)\left(z-2\right)$$

jabarkan


\>$&expand((z-1)\*(z-2))


$$z^2-3\,z+2$$Kita bisa melihat bentuk expand yang lebih sederhana


No 21


$$\left(x+6\right)\left(x+3\right)$$

jabarkan


\>$&expand((x+6)\*(x+3))


$$x^2+9\,x+18$$Kita bisa melihat bentuk expand yang lebih sederhana


No 22


$$\left(a-8\right)\left(a-1\right)$$

jabarkan


\>$&expand((a-8)\*(a-1))


$$a^2-9\,a+8$$Kita bisa melihat bentuk expand yang lebih sederhana


No 23


$$\left(2a+3\right)\left(a+5\right)$$

jabarkan


\>$&expand((2\*a+3)\*(a+5))


$$2\,a^2+13\,a+15$$Kita bisa melihat bentuk expand yang lebih sederhana


No 24


$$\left(3b+1\right)\left(b-2\right)$$

jabarkan


\>$&expand((3\*b+1)\*(b-2))


$$3\,b^2-5\,b-2$$Kita bisa melihat bentuk expand yang lebih sederhana


No 25


$$\left(2x+3y\right)\left(2x+y\right)$$

jabarkan


\>$&expand((2\*x+3\*y)\*(2\*x+y))


$$3\,y^2+8\,x\,y+4\,x^2$$Kita bisa melihat bentuk expand yang lebih sederhana


# R.4

No 47


faktorkan


\>$&factor(z^2-81)


$$\left(z-9\right)\,\left(z+9\right)$$Kita bisa melihat bentuk pemfaktoran yang lebih sederhana


N0 81


$$8x^2-32$$faktorkan


\>$&factor(8\*x^2-32)


$$8\,\left(x-2\right)\,\left(x+2\right)$$Kita bisa melihat bentuk pemfaktoran yang lebih sederhana


No 82


faktorkan


\>$&factor(6\*y^2-6)


Kita bisa melihat bentuk pemfaktoran yang lebih sederhana


No 90


$$x^2-4x-21$$faktorkan


\>$&factor(x^2-4\*x-21)


$$\left(x-7\right)\,\left(x+3\right)$$Kita bisa melihat bentuk pemfaktoran yang lebih sederhana


No 91


$$2a^2 +9a +4$$faktorkan


\>$&factor(2\*a^2+9\*a+4)


$$\left(a+4\right)\,\left(2\,a+1\right)$$Kita bisa melihat bentuk pemfaktoran yang lebih sederhana


# R.5

No 47


temukan z


\>$&solve(12\*z^2+z=6)


$$\left[ z=-\frac{3}{4} , z=\frac{2}{3} \right] $$kita bisa menemukan variabel dengan operasi aljabar yang ada


No 53


$$x^2-36=0$$temukan x


\>$&solve(x^2-36=0)


$$\left[ x=-6 , x=6 \right] $$kita bisa menemukan variabel dengan operasi aljabar yang ada


No 54


$$y^2-81=0$$temukan y


\>$&solve(y^2-81=0)


$$\left[ y=-9 , y=9 \right] $$kita bisa menemukan variabel dengan operasi aljabar yang ada


No 60


$$5x^2 -75$$temukan x


\>$&solve(5\*x^2-75=0)


$$\left[ x=-\sqrt{15} , x=\sqrt{15} \right] $$kita bisa menemukan variabel dengan operasi aljabar yang ada


No 86


temukan x


\>$&solve((3\*x^2+7\*x-20)\*(x^2-4\*x))


$$\left[ x=\frac{5}{3} , x=-4 , x=0 , x=4 \right] $$kita bisa menemukan variabel dengan operasi aljabar yang ada


# R.6

No 9


Simplify


$$\frac{x^2-4}{x^2-4x+4}$$$$\frac{(x+2)(x-2)}{(x-2)^2}$$\>$&((x+2)\*(x-2))/(x-2)^2


$$\frac{x+2}{x-2}$$Dengan penyederhanaan kita bisa memperoleh hasil yang lebih simpel


No 11


Simplify


$$\frac{(x-3)^2 \cdot x}{(x-3) \cdot x^2}$$\>$&((x-3)^2 \* x)/((x-3) \* x^2)


$$\frac{x-3}{x}$$Dengan penyederhanaan kita bisa memperoleh hasil yang lebih simpel


No 17


$$\frac{r-s}{r+s} \cdot \frac{r^2-s^2}{(r-s)^2}$$\>$&(r^2-s^2)/(r-s)\*(s+r), $&ratsimp(%)


Dengan penyederhanaan kita bisa memperoleh hasil yang lebih simpel


No 28


Simplify


$$\frac{(c^3+8)}{(c^2-4)} : \frac{(c^2-2c+4)}{(c^2-4c+4)}$$\>$&ratsimp((c^3+8)/(c^2-4))/((c^2-2\*c+4)/(c^2-4\*c+4)), $&ratsimp(%)


$$c-2$$![images/Nur%20Muhammad%20Al%20Fahamiey_23030630058_Exercise-046.png](images/Nur%20Muhammad%20Al%20Fahamiey_23030630058_Exercise-046.png)

Dengan penyederhanaan kita bisa memperoleh hasil yang lebih simpel


No 40


$$\frac{6}{y^2+6y+9} - \frac{5}{y-3}$$\>$&expand(6/y^2+6\*y+9)-(5/y-3), $&ratsimp(%)


$$\frac{6\,y^3+12\,y^2-5\,y+6}{y^2}$$![images/Nur%20Muhammad%20Al%20Fahamiey_23030630058_Exercise-049.png](images/Nur%20Muhammad%20Al%20Fahamiey_23030630058_Exercise-049.png)

Dengan penyederhanaan kita bisa memperoleh hasil yang lebih simpel


No 62


Simplify


$$\frac{\frac{a^2}{b}+\frac{b^2}{a}}{{a^2-ab+b^2}}$$

Penyelesaian:


\>$&factor((a^2/b)+(b^2/a))/(a^2-a\*b+b^2)


$$\frac{b+a}{a\,b}$$Dengan penyederhanaan kita bisa memperoleh hasil yang lebih simpel


# Review Exercice

No 70


$$(x^n + 10)(x^n -4)$$\>$&expand((x^n + 10)\*(x^n - 4))


$$x^{2\,n}+6\,x^{n}-40$$Kita bisa melihat bentuk expand yang lebih sederhana


No 71


$$(a^n - b^n)^3$$\>$&expand((t^a + t^(-a))^2)


$$t^{2\,a}+\frac{1}{t^{2\,a}}+2$$Kita bisa melihat bentuk expand yang lebih sederhana


 No 72  

$$(y^z - z^c)(y^b + z^c)$$\>$&expand((y^z - z^c)\*(y^b + z^c))


$$-z^{2\,c}+y^{z}\,z^{c}-y^{b}\,z^{c}+y^{z+b}$$Kita bisa melihat bentuk expand yang lebih sederhana


No 73


$$(a^n - b^n)^3$$\>$&showev('expand((a^n - b^n)^3)), $&expand((a^n - b^n)^3)


Kita bisa melihat bentuk expand yang lebih sederhana


No 76


\>$&factor(m^6-m^3)


$$\left(m-1\right)\,m^3\,\left(m^2+m+1\right)$$Kita bisa melihat bentuk expand yang lebih sederhana


## 2.3 Exercise Set

Given that


$$f(x) = 3x + 1$$$$g(x) = x^2 - 2x -6$$$$h(x) = x^3$$

Find each of the following


Menyimpan semua nilai fx, gx, dan hx.


\>fx &= 3\*x + 1


    
                                   3 x + 1
    

\>gx &= x^2 - 2\*x - 6


    
                                  2
                                 x  - 2 x - 6
    

\>hx &= x^3


    
                                       3
                                      x
    

No 1


mencari nilai


$$(f \circ g)(-1)$$

Penyelesaian:


fungsi komposisi di atas juga dapat ditulis sebagai :


$$(f(g(-1))$$mencari nilai g(-1)


\>fx(gx(-1))


    -8

didapatkan nilai fungsi komposisi dengan operasi aljabar


No 2


mencari nilai g(f(-2)


\>gx(fx(-2))


    29

didapatkan nilai fungsi komposisi dengan operasi aljabar


No 3


mencari nilai h(f(1)


\>hx(fx(1))


    64

didapatkan nilai fungsi komposisi dengan operasi aljabar


No 5


mencari nilai g(f(5)


\>gx(fx(5))


    218

didapatkan nilai fungsi komposisi dengan operasi aljabar


No 8


mencari nilai h(g(3)


\>hx(gx(3))


    -27

didapatkan nilai fungsi komposisi dengan operasi aljabar


# Exercise 3.1

NO 11


Simplify


$$(-5+3i) + (7+8i)$$\>bilangan1 = -5 + 3\*I, bilangan2 = 7 + 8\*I, bilangan1 + bilangan2


    -5+3i
    7+8i
    2+11i

Didapatkan hasil operasi string


NO 12


Simplify


$$(-6-5i) + (9+2i)$$\>bilangan1 = -6 - 5\*I, bilangan2 = 9 + 2\*I, bilangan1 + bilangan2


    -6-5i
    9+2i
    3-3i

Didapatkan hasil operasi string


NO 13


Simplify


$$(4-9i) + (1-4i)$$\>bilangan1 = 4 - 9\*I, bilangan2 = 1 -4\*I, bilangan1 + bilangan2


    4-9i
    1-4i
    5-13i

NO 14


Simplify


$$(7-2i) + (4-5i)$$\>bilangan1 = 7 - 2\*I, bilangan2 = 4 -5\*I, bilangan1 + bilangan2


    7-2i
    4-5i
    11-7i

Didapatkan hasil operasi string


NO 15


Simplify


$$(12+3i) + (-8+5i)$$\>bilangan1 = 12+3\*I, bilangan2 = -8+5\*I, bilangan1 + bilangan2


    12+3i
    -8+5i
    4+8i

Didapatkan hasil operasi string


# 3.4 No 1

 Solve  
 latex: \frac{1}{4} + \frac{1}{5} = \frac{1}{t}  

\>$&(1/4+1/5=1/t), $&solve(1/4+1/5=1/t)


$$\left[ t=\frac{20}{9} \right] $$![images/Nur%20Muhammad%20Al%20Fahamiey_23030630058_Exercise-071.png](images/Nur%20Muhammad%20Al%20Fahamiey_23030630058_Exercise-071.png)

Penyelesaian aljabar dapat kita peroleh nilai variabel


No 2


Solve


$$\frac{1}{3} + \frac{5}{6} = \frac{1}{x}$$\>$&(1/3-5/6=1/x), $&solve(1/3-5/6=1/x)


$$\left[ x=-2 \right] $$![images/Nur%20Muhammad%20Al%20Fahamiey_23030630058_Exercise-074.png](images/Nur%20Muhammad%20Al%20Fahamiey_23030630058_Exercise-074.png)

Penyelesaian aljabar dapat kita peroleh nilai variabel


No 3


Solve


$$\frac{x+2}{4} - \frac{x-1}{5} = 15$$\>$&solve(((x+2)/4)-((x-1)/5)=15)


$$\left[ x=286 \right] $$Penyelesaian aljabar dapat kita peroleh nilai variabel


No 4


Solve


$$\frac{t+1}{3} - \frac{t-1}{2} = 1$$\>$&solve(((t+1)/3)-((t-1)/2))


$$\left[ t=5 \right] $$Penyelesaian aljabar dapat kita peroleh nilai variabel


No 5


Solve


$$\frac{1}{2} + \frac{2}{x} = \frac{1}{3} +\frac{3}{x}$$\>$&solve(1/2+2/x=1/3+3/x)


$$\left[ x=6 \right] $$Penyelesaian aljabar dapat kita peroleh nilai variabel


# 3.5

No 23


Solve


$$\left| x+3 \right|-2 = 8$$\>$&solve(abs(x+3)-2=8, x)


$$\left[ \left| x+3\right| =10 \right] $$\>$&solve((x+3)=10)


$$\left[ x=7 \right] $$dapat kita peroleh nilai variabel dari operasi nilai mutlak


No 24


Solve


$$\left| x-4 \right|+3 = 9$$\>$&solve(abs(x-4)+3=9, x)


$$\left[ \left| x-4\right| =6 \right] $$\>$&solve((x-4)=6)


$$\left[ x=10 \right] $$dapat kita peroleh nilai variabel dari operasi nilai mutlak


No 25


$$\left| 3x-4 \right|-4 = -1$$\>$&solve(abs(3\*x-4)-4=-1, x)


$$\left[ \left| 3\,x-4\right| =3 \right] $$\>$&solve((3\*x-4)=3)


$$\left[ x=\frac{7}{3} \right] $$dapat kita peroleh nilai variabel dari operasi nilai mutlak


No 26


$$\left| 2x-1 \right|-5= -3$$\>$&solve(abs(2\*x-1)-5=-3, x)


$$\left[ \left| 2\,x-1\right| =2 \right] $$\>$&solve((2\*x-1)=2)


$$\left[ x=\frac{3}{2} \right] $$dapat kita peroleh nilai variabel dari operasi nilai mutlak


No 27


$$\left| 4x-3 \right|+1= 7$$\>$&solve(abs(4\*x-3)+1=7, x)


$$\left[ \left| 4\,x-3\right| =6 \right] $$\>$&solve((4\*x-3)=6)


$$\left[ x=\frac{9}{4} \right] $$dapat kita peroleh nilai variabel dari operasi nilai mutlak


# Chapter 3 Test

No 9


Solve


$$\sqrt{x+4}-2=1$$\>$&solve(((x+4)^1/2)-2=1)


Penyelesaian aljabar dapat kita peroleh nilai variabel


No 10


Solve


$$\sqrt{x+4}-\sqrt{x-4}=2$$\>$&solve(((x+4)^1/2)-((x-4)^1/2=2))


$$\left[ x=8 \right] $$Penyelesaian aljabar dapat kita peroleh nilai variabel


No 11


$$\left| x+4 \right| = 7$$\>$&solve((x+4)=7)


$$\left[ x=3 \right] $$Penyelesaian aljabar dapat kira peroleh nilai variabel


No 12


$$\left| 4y-3 \right| = 5$$\>$&solve((4\*y-3)=5)


Penyelesaian aljabar dapat kita peroleh nilai variabel


No 13


Selesaikan dan tulis notasi interval untuk kumpulan solusi.


kemudian grafik set solusi


$$\left|x+3\right|\leq4$$\>&load(fourier\_elim)


    
            C:/Program Files/Euler x64/maxima/share/maxima/5.35.1/share/f\
    ourier_elim/fourier_elim.lisp
    

\>$&fourier\_elim([abs(x+3)<=4], [x])


$$\left[ x=1 \right] \lor \left[ x=-7 \right] \lor \left[ -7<x , x<1   \right] $$Penyelesaian aljabar dapat kita peroleh nilai variabel


# 4.1

No 36


Temukan nol dari fungsi polinomial dan nyatakan keragaman
masing-masing


$$f(x) = (x^2-5x+6)^2$$\>$&solve((x^2-5\*x+6)^2)


$$\left[ x=3 , x=2 \right] $$Penyelesaian aljabar dapat kita peroleh nilai variabel


No 37


Temukan nol dari fungsi polinomial dan nyatakan keragaman
masing-masing


$$f(x) = x^4-4x^2+3$$\>$&solve(x^4-4\*x^2+3)


$$\left[ x=-1 , x=1 , x=-\sqrt{3} , x=\sqrt{3} \right] $$Penyelesaian aljabar dapat kita peroleh nilai variabel


No 38


Temukan nol dari fungsi polinomial dan nyatakan keragaman
masing-masing


$$f(x) = x^4-10x^2+9$$\>$&solve(x^4-10\*x^2+9)


$$\left[ x=-1 , x=1 , x=-3 , x=3 \right] $$Penyelesaian aljabar dapat kita peroleh nilai variabel


No 39


Temukan nol dari fungsi polinomial dan nyatakan keragaman
masing-masing


$$f(x) = x^3-3x^2-x-3$$\>$&solve(x^3-3\*x^2-x-3)


$$\left[ x=\frac{4\,\left(\frac{\sqrt{3}\,i}{2}-\frac{1}{2}\right)}{3  \,\left(\frac{\sqrt{179}}{3^{\frac{3}{2}}}+3\right)^{\frac{1}{3}}}+  \left(\frac{\sqrt{179}}{3^{\frac{3}{2}}}+3\right)^{\frac{1}{3}}\,  \left(-\frac{\sqrt{3}\,i}{2}-\frac{1}{2}\right)+1 , x=\left(\frac{  \sqrt{179}}{3^{\frac{3}{2}}}+3\right)^{\frac{1}{3}}\,\left(\frac{  \sqrt{3}\,i}{2}-\frac{1}{2}\right)+\frac{4\,\left(-\frac{\sqrt{3}\,i  }{2}-\frac{1}{2}\right)}{3\,\left(\frac{\sqrt{179}}{3^{\frac{3}{2}}}  +3\right)^{\frac{1}{3}}}+1 , x=\left(\frac{\sqrt{179}}{3^{\frac{3}{2  }}}+3\right)^{\frac{1}{3}}+\frac{4}{3\,\left(\frac{\sqrt{179}}{3^{  \frac{3}{2}}}+3\right)^{\frac{1}{3}}}+1 \right] $$Penyelesaian aljabar dapat kita peroleh nilai variabel


No 40


Temukan nol dari fungsi polinomial dan nyatakan keragaman
masing-masing


$$f(x) = x^3-x^2-2x+2$$\>$&solve(x^3-x^2-2\*x+2)


$$\left[ x=-\sqrt{2} , x=\sqrt{2} , x=1 \right] $$Penyelesaian aljabar dapat kira peroleh nilai variabel


# 4.1

Nomor 11-15


Gunakan pembagian sintetis untuk menemukan hasil bagi dan sisa.


No 11


$$\frac{2x^4 + 7x^3 + x - 12}{x + 3}$$\>$&((2\*x^4+7\*x^3+x-12)/(x+3)), $&solve((2\*x^4+7\*x^3+x-12)/(x+3))


$$\left[ x=-\frac{\sqrt{\frac{125\,3^{\frac{3}{2}}\,\left(\frac{5\,  \sqrt{68213}}{2\,6^{\frac{3}{2}}}-\frac{293}{8}\right)^{\frac{1}{6}}  }{8\,\sqrt{48\,\left(\frac{5\,\sqrt{68213}}{2\,6^{\frac{3}{2}}}-  \frac{293}{8}\right)^{\frac{2}{3}}+147\,\left(\frac{5\,\sqrt{68213}  }{2\,6^{\frac{3}{2}}}-\frac{293}{8}\right)^{\frac{1}{3}}-412}}-  \left(\frac{5\,\sqrt{68213}}{2\,6^{\frac{3}{2}}}-\frac{293}{8}  \right)^{\frac{1}{3}}+\frac{103}{12\,\left(\frac{5\,\sqrt{68213}}{2  \,6^{\frac{3}{2}}}-\frac{293}{8}\right)^{\frac{1}{3}}}+\frac{49}{8}}  }{2}-\frac{\sqrt{48\,\left(\frac{5\,\sqrt{68213}}{2\,6^{\frac{3}{2}}  }-\frac{293}{8}\right)^{\frac{2}{3}}+147\,\left(\frac{5\,\sqrt{68213  }}{2\,6^{\frac{3}{2}}}-\frac{293}{8}\right)^{\frac{1}{3}}-412}}{8\,  \sqrt{3}\,\left(\frac{5\,\sqrt{68213}}{2\,6^{\frac{3}{2}}}-\frac{293  }{8}\right)^{\frac{1}{6}}}-\frac{7}{8} , x=\frac{\sqrt{\frac{125\,3  ^{\frac{3}{2}}\,\left(\frac{5\,\sqrt{68213}}{2\,6^{\frac{3}{2}}}-  \frac{293}{8}\right)^{\frac{1}{6}}}{8\,\sqrt{48\,\left(\frac{5\,  \sqrt{68213}}{2\,6^{\frac{3}{2}}}-\frac{293}{8}\right)^{\frac{2}{3}}  +147\,\left(\frac{5\,\sqrt{68213}}{2\,6^{\frac{3}{2}}}-\frac{293}{8}  \right)^{\frac{1}{3}}-412}}-\left(\frac{5\,\sqrt{68213}}{2\,6^{  \frac{3}{2}}}-\frac{293}{8}\right)^{\frac{1}{3}}+\frac{103}{12\,  \left(\frac{5\,\sqrt{68213}}{2\,6^{\frac{3}{2}}}-\frac{293}{8}  \right)^{\frac{1}{3}}}+\frac{49}{8}}}{2}-\frac{\sqrt{48\,\left(  \frac{5\,\sqrt{68213}}{2\,6^{\frac{3}{2}}}-\frac{293}{8}\right)^{  \frac{2}{3}}+147\,\left(\frac{5\,\sqrt{68213}}{2\,6^{\frac{3}{2}}}-  \frac{293}{8}\right)^{\frac{1}{3}}-412}}{8\,\sqrt{3}\,\left(\frac{5  \,\sqrt{68213}}{2\,6^{\frac{3}{2}}}-\frac{293}{8}\right)^{\frac{1}{6  }}}-\frac{7}{8} , x=-\frac{\sqrt{-\frac{125\,3^{\frac{3}{2}}\,\left(  \frac{5\,\sqrt{68213}}{2\,6^{\frac{3}{2}}}-\frac{293}{8}\right)^{  \frac{1}{6}}}{8\,\sqrt{48\,\left(\frac{5\,\sqrt{68213}}{2\,6^{\frac{  3}{2}}}-\frac{293}{8}\right)^{\frac{2}{3}}+147\,\left(\frac{5\,  \sqrt{68213}}{2\,6^{\frac{3}{2}}}-\frac{293}{8}\right)^{\frac{1}{3}}  -412}}-\left(\frac{5\,\sqrt{68213}}{2\,6^{\frac{3}{2}}}-\frac{293}{8  }\right)^{\frac{1}{3}}+\frac{103}{12\,\left(\frac{5\,\sqrt{68213}}{2  \,6^{\frac{3}{2}}}-\frac{293}{8}\right)^{\frac{1}{3}}}+\frac{49}{8}}  }{2}+\frac{\sqrt{48\,\left(\frac{5\,\sqrt{68213}}{2\,6^{\frac{3}{2}}  }-\frac{293}{8}\right)^{\frac{2}{3}}+147\,\left(\frac{5\,\sqrt{68213  }}{2\,6^{\frac{3}{2}}}-\frac{293}{8}\right)^{\frac{1}{3}}-412}}{8\,  \sqrt{3}\,\left(\frac{5\,\sqrt{68213}}{2\,6^{\frac{3}{2}}}-\frac{293  }{8}\right)^{\frac{1}{6}}}-\frac{7}{8} , x=\frac{\sqrt{-\frac{125\,3  ^{\frac{3}{2}}\,\left(\frac{5\,\sqrt{68213}}{2\,6^{\frac{3}{2}}}-  \frac{293}{8}\right)^{\frac{1}{6}}}{8\,\sqrt{48\,\left(\frac{5\,  \sqrt{68213}}{2\,6^{\frac{3}{2}}}-\frac{293}{8}\right)^{\frac{2}{3}}  +147\,\left(\frac{5\,\sqrt{68213}}{2\,6^{\frac{3}{2}}}-\frac{293}{8}  \right)^{\frac{1}{3}}-412}}-\left(\frac{5\,\sqrt{68213}}{2\,6^{  \frac{3}{2}}}-\frac{293}{8}\right)^{\frac{1}{3}}+\frac{103}{12\,  \left(\frac{5\,\sqrt{68213}}{2\,6^{\frac{3}{2}}}-\frac{293}{8}  \right)^{\frac{1}{3}}}+\frac{49}{8}}}{2}+\frac{\sqrt{48\,\left(  \frac{5\,\sqrt{68213}}{2\,6^{\frac{3}{2}}}-\frac{293}{8}\right)^{  \frac{2}{3}}+147\,\left(\frac{5\,\sqrt{68213}}{2\,6^{\frac{3}{2}}}-  \frac{293}{8}\right)^{\frac{1}{3}}-412}}{8\,\sqrt{3}\,\left(\frac{5  \,\sqrt{68213}}{2\,6^{\frac{3}{2}}}-\frac{293}{8}\right)^{\frac{1}{6  }}}-\frac{7}{8} \right] $$![images/Nur%20Muhammad%20Al%20Fahamiey_23030630058_Exercise-116.png](images/Nur%20Muhammad%20Al%20Fahamiey_23030630058_Exercise-116.png)

EMT operasi aljabar dapat membantu untuk menghitung operasi yang
kompleks


No 12


$$\frac{x^3 - 7x^2 + 13x + 3}{x - 2}$$\>$&((x^3-7\*x^2+13\*x+3)/(x-2)), $&solve((x^3-7\*x^2+13\*x+3)/(x-2))


$$\left[ x=\frac{10\,\left(\frac{\sqrt{3}\,i}{2}-\frac{1}{2}\right)}{  9\,\left(\frac{\sqrt{43}}{\sqrt{3}}-\frac{107}{27}\right)^{\frac{1}{  3}}}+\left(\frac{\sqrt{43}}{\sqrt{3}}-\frac{107}{27}\right)^{\frac{1  }{3}}\,\left(-\frac{\sqrt{3}\,i}{2}-\frac{1}{2}\right)+\frac{7}{3}   , x=\left(\frac{\sqrt{43}}{\sqrt{3}}-\frac{107}{27}\right)^{\frac{1  }{3}}\,\left(\frac{\sqrt{3}\,i}{2}-\frac{1}{2}\right)+\frac{10\,  \left(-\frac{\sqrt{3}\,i}{2}-\frac{1}{2}\right)}{9\,\left(\frac{  \sqrt{43}}{\sqrt{3}}-\frac{107}{27}\right)^{\frac{1}{3}}}+\frac{7}{3  } , x=\left(\frac{\sqrt{43}}{\sqrt{3}}-\frac{107}{27}\right)^{\frac{  1}{3}}+\frac{10}{9\,\left(\frac{\sqrt{43}}{\sqrt{3}}-\frac{107}{27}  \right)^{\frac{1}{3}}}+\frac{7}{3} \right] $$![images/Nur%20Muhammad%20Al%20Fahamiey_23030630058_Exercise-119.png](images/Nur%20Muhammad%20Al%20Fahamiey_23030630058_Exercise-119.png)

EMT operasi aljabar dapat membantu untuk menghitung operasi yang
kompleks


No 13


$$\frac{x^3 - 2x^2 - 8}{x + 2}$$\>$&((x^3-2\*x^2-8)/(x+2)), $&solve((x^3-2\*x^2-8)/(x+2))


$$\left[ x=\frac{4\,\left(\frac{\sqrt{3}\,i}{2}-\frac{1}{2}\right)}{9  \,\left(\frac{4\,\sqrt{31}}{3^{\frac{3}{2}}}+\frac{116}{27}\right)^{  \frac{1}{3}}}+\left(\frac{4\,\sqrt{31}}{3^{\frac{3}{2}}}+\frac{116}{  27}\right)^{\frac{1}{3}}\,\left(-\frac{\sqrt{3}\,i}{2}-\frac{1}{2}  \right)+\frac{2}{3} , x=\left(\frac{4\,\sqrt{31}}{3^{\frac{3}{2}}}+  \frac{116}{27}\right)^{\frac{1}{3}}\,\left(\frac{\sqrt{3}\,i}{2}-  \frac{1}{2}\right)+\frac{4\,\left(-\frac{\sqrt{3}\,i}{2}-\frac{1}{2}  \right)}{9\,\left(\frac{4\,\sqrt{31}}{3^{\frac{3}{2}}}+\frac{116}{27  }\right)^{\frac{1}{3}}}+\frac{2}{3} , x=\left(\frac{4\,\sqrt{31}}{3  ^{\frac{3}{2}}}+\frac{116}{27}\right)^{\frac{1}{3}}+\frac{4}{9\,  \left(\frac{4\,\sqrt{31}}{3^{\frac{3}{2}}}+\frac{116}{27}\right)^{  \frac{1}{3}}}+\frac{2}{3} \right] $$![images/Nur%20Muhammad%20Al%20Fahamiey_23030630058_Exercise-122.png](images/Nur%20Muhammad%20Al%20Fahamiey_23030630058_Exercise-122.png)

EMT operasi aljabar dapat membantu untuk menghitung operasi yang
kompleks


No 14


$$\frac{x^3 - 3x + 10}{x - 2}$$\>$&((x^3-3\*x+10)/(x-2)), $&solve((x^3-3\*x+10)/(x-2))


$$\left[ x=\frac{\frac{\sqrt{3}\,i}{2}-\frac{1}{2}}{\left(2\,\sqrt{6}  -5\right)^{\frac{1}{3}}}+\left(2\,\sqrt{6}-5\right)^{\frac{1}{3}}\,  \left(-\frac{\sqrt{3}\,i}{2}-\frac{1}{2}\right) , x=\left(2\,\sqrt{6  }-5\right)^{\frac{1}{3}}\,\left(\frac{\sqrt{3}\,i}{2}-\frac{1}{2}  \right)+\frac{-\frac{\sqrt{3}\,i}{2}-\frac{1}{2}}{\left(2\,\sqrt{6}-  5\right)^{\frac{1}{3}}} , x=\left(2\,\sqrt{6}-5\right)^{\frac{1}{3}}  +\frac{1}{\left(2\,\sqrt{6}-5\right)^{\frac{1}{3}}} \right] $$![images/Nur%20Muhammad%20Al%20Fahamiey_23030630058_Exercise-125.png](images/Nur%20Muhammad%20Al%20Fahamiey_23030630058_Exercise-125.png)

EMT operasi aljabar dapat membantu untuk menghitung operasi yang
kompleks


No 15


$$\frac{3x^3 - x^2 + 4x - 10}{x + 1}$$\>$&((3\*x^3-x^2+4\*x-10)/(x+1)), $&solve((3\*x^3-x^2+4\*x-10)/(x+1))


$$\left[ x=-\frac{35\,\left(\frac{\sqrt{3}\,i}{2}-\frac{1}{2}\right)  }{81\,\left(\frac{7\,\sqrt{13}}{3^{\frac{5}{2}}}+\frac{1162}{729}  \right)^{\frac{1}{3}}}+\left(\frac{7\,\sqrt{13}}{3^{\frac{5}{2}}}+  \frac{1162}{729}\right)^{\frac{1}{3}}\,\left(-\frac{\sqrt{3}\,i}{2}-  \frac{1}{2}\right)+\frac{1}{9} , x=\left(\frac{7\,\sqrt{13}}{3^{  \frac{5}{2}}}+\frac{1162}{729}\right)^{\frac{1}{3}}\,\left(\frac{  \sqrt{3}\,i}{2}-\frac{1}{2}\right)-\frac{35\,\left(-\frac{\sqrt{3}\,  i}{2}-\frac{1}{2}\right)}{81\,\left(\frac{7\,\sqrt{13}}{3^{\frac{5}{  2}}}+\frac{1162}{729}\right)^{\frac{1}{3}}}+\frac{1}{9} , x=\left(  \frac{7\,\sqrt{13}}{3^{\frac{5}{2}}}+\frac{1162}{729}\right)^{\frac{  1}{3}}-\frac{35}{81\,\left(\frac{7\,\sqrt{13}}{3^{\frac{5}{2}}}+  \frac{1162}{729}\right)^{\frac{1}{3}}}+\frac{1}{9} \right] $$![images/Nur%20Muhammad%20Al%20Fahamiey_23030630058_Exercise-128.png](images/Nur%20Muhammad%20Al%20Fahamiey_23030630058_Exercise-128.png)

EMT operasi aljabar dapat membantu untuk menghitung operasi yang
kompleks


# Mid-Chapter Mixed Review

Nomor 16-17


Gunakan pembagian sintetis untuk menemukan hasil bagi dan sisanya


No 16


$$\frac{(3x^4-x^3 + 2x^2-6x+6)}{(x-2)}$$\>$&solve((3\*x^4-x^3 + 2\*x^2-6\*x+6)/(x-2))


$$\left[ x=-\frac{\sqrt{-\frac{409}{6\,\sqrt{\frac{324\,\left(\frac{  \sqrt{101279}\,i}{81}+\frac{197}{729}\right)^{\frac{2}{3}}-135\,  \left(\frac{\sqrt{101279}\,i}{81}+\frac{197}{729}\right)^{\frac{1}{3  }}+808}{\left(\frac{\sqrt{101279}\,i}{81}+\frac{197}{729}\right)^{  \frac{1}{3}}}}}-\left(\frac{\sqrt{101279}\,i}{81}+\frac{197}{729}  \right)^{\frac{1}{3}}-\frac{202}{81\,\left(\frac{\sqrt{101279}\,i}{  81}+\frac{197}{729}\right)^{\frac{1}{3}}}-\frac{5}{6}}}{2}-\frac{  \sqrt{\frac{324\,\left(\frac{\sqrt{101279}\,i}{81}+\frac{197}{729}  \right)^{\frac{2}{3}}-135\,\left(\frac{\sqrt{101279}\,i}{81}+\frac{  197}{729}\right)^{\frac{1}{3}}+808}{\left(\frac{\sqrt{101279}\,i}{81  }+\frac{197}{729}\right)^{\frac{1}{3}}}}}{36}+\frac{1}{12} , x=  \frac{\sqrt{-\frac{409}{6\,\sqrt{\frac{324\,\left(\frac{\sqrt{101279  }\,i}{81}+\frac{197}{729}\right)^{\frac{2}{3}}-135\,\left(\frac{  \sqrt{101279}\,i}{81}+\frac{197}{729}\right)^{\frac{1}{3}}+808}{  \left(\frac{\sqrt{101279}\,i}{81}+\frac{197}{729}\right)^{\frac{1}{3  }}}}}-\left(\frac{\sqrt{101279}\,i}{81}+\frac{197}{729}\right)^{  \frac{1}{3}}-\frac{202}{81\,\left(\frac{\sqrt{101279}\,i}{81}+\frac{  197}{729}\right)^{\frac{1}{3}}}-\frac{5}{6}}}{2}-\frac{\sqrt{\frac{  324\,\left(\frac{\sqrt{101279}\,i}{81}+\frac{197}{729}\right)^{  \frac{2}{3}}-135\,\left(\frac{\sqrt{101279}\,i}{81}+\frac{197}{729}  \right)^{\frac{1}{3}}+808}{\left(\frac{\sqrt{101279}\,i}{81}+\frac{  197}{729}\right)^{\frac{1}{3}}}}}{36}+\frac{1}{12} , x=-\frac{\sqrt{  \frac{409}{6\,\sqrt{\frac{324\,\left(\frac{\sqrt{101279}\,i}{81}+  \frac{197}{729}\right)^{\frac{2}{3}}-135\,\left(\frac{\sqrt{101279}  \,i}{81}+\frac{197}{729}\right)^{\frac{1}{3}}+808}{\left(\frac{  \sqrt{101279}\,i}{81}+\frac{197}{729}\right)^{\frac{1}{3}}}}}-\left(  \frac{\sqrt{101279}\,i}{81}+\frac{197}{729}\right)^{\frac{1}{3}}-  \frac{202}{81\,\left(\frac{\sqrt{101279}\,i}{81}+\frac{197}{729}  \right)^{\frac{1}{3}}}-\frac{5}{6}}}{2}+\frac{\sqrt{\frac{324\,  \left(\frac{\sqrt{101279}\,i}{81}+\frac{197}{729}\right)^{\frac{2}{3  }}-135\,\left(\frac{\sqrt{101279}\,i}{81}+\frac{197}{729}\right)^{  \frac{1}{3}}+808}{\left(\frac{\sqrt{101279}\,i}{81}+\frac{197}{729}  \right)^{\frac{1}{3}}}}}{36}+\frac{1}{12} , x=\frac{\sqrt{\frac{409  }{6\,\sqrt{\frac{324\,\left(\frac{\sqrt{101279}\,i}{81}+\frac{197}{  729}\right)^{\frac{2}{3}}-135\,\left(\frac{\sqrt{101279}\,i}{81}+  \frac{197}{729}\right)^{\frac{1}{3}}+808}{\left(\frac{\sqrt{101279}  \,i}{81}+\frac{197}{729}\right)^{\frac{1}{3}}}}}-\left(\frac{\sqrt{  101279}\,i}{81}+\frac{197}{729}\right)^{\frac{1}{3}}-\frac{202}{81\,  \left(\frac{\sqrt{101279}\,i}{81}+\frac{197}{729}\right)^{\frac{1}{3  }}}-\frac{5}{6}}}{2}+\frac{\sqrt{\frac{324\,\left(\frac{\sqrt{101279  }\,i}{81}+\frac{197}{729}\right)^{\frac{2}{3}}-135\,\left(\frac{  \sqrt{101279}\,i}{81}+\frac{197}{729}\right)^{\frac{1}{3}}+808}{  \left(\frac{\sqrt{101279}\,i}{81}+\frac{197}{729}\right)^{\frac{1}{3  }}}}}{36}+\frac{1}{12} \right] $$Penyelesaian aljabar dapat kita peroleh nilai variabel


No 17


$$\frac{x^5-5}{x+1}$$\>$&expand((x^5-5)/(x+1)), $&solve((x^5-5)/(x+1))


$$\left[ x=5^{\frac{1}{5}}\,e^{\frac{2\,i\,\pi}{5}} , x=5^{\frac{1}{5  }}\,e^{\frac{4\,i\,\pi}{5}} , x=5^{\frac{1}{5}}\,e^ {- \frac{4\,i\,  \pi}{5} } , x=5^{\frac{1}{5}}\,e^ {- \frac{2\,i\,\pi}{5} } , x=5^{  \frac{1}{5}} \right] $$![images/Nur%20Muhammad%20Al%20Fahamiey_23030630058_Exercise-133.png](images/Nur%20Muhammad%20Al%20Fahamiey_23030630058_Exercise-133.png)

Penyelesaian aljabar dapat kita peroleh nilai variabel


No 18


Gunakan pembagian sintetis untuk menemukan nilai fungsi


$$f(x)=x^3-9x^2+4x-10;$$$$f(-5)$$\>function f(x) :=(x^3-9\*x^2+4\*x-10)

\>f(-5)


    -380

No 19


$$f(x)=20x^2-40x;$$$$f(\frac{1}{2})$$\>function f(x) :=(20\*x^2-40\*x)

\>f(1/2)


    -15

kita dapat menemukan nilai fungsi sesuai yang dicari


No 20


$$f(x) = 5x^4+x^3-x;$$$$f(-\sqrt{2})$$\>fx &= 5\*x^4 + x^3 - x; fx(-sqrt(2))


    18.5857864376

kita dapat menemukan nilai fungsi sesuai yang dicari


