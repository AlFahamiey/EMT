﻿# 23030630058_Nur Muhammad Al Fahamiey_Soal Plot 3D
# Soal plot 3D 1. Grafik dengan ekspresi langsung latex: x^3+2y

\>plot3d("x^3+2\*y",distance=3,zoom=1,angle=pi/2,height=0):


![images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_Soal%20Plot%203D-001.png](images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_Soal%20Plot%203D-001.png)

plot 3d dengan ekspresi


$$x^3+2y$$

akan membentuk grafik tersebut dengan jarak 3, pembesaran 1 kali,
kemiringan pi/2, dan ketinggian 0


# Grafik dengan menyimpan variabel latex: f(x)=x^2+3y

\>function f(x,y):= x^2+3\*y

\>x=3; plot3d("f",0,1,0,distance=3,zoom=2,angle=pi,height=0):


![images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_Soal%20Plot%203D-003.png](images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_Soal%20Plot%203D-003.png)

plot 3d dengan ekspresi


$$x^2+3y$$

akan membentuk grafik tersebut dengan jarak 3, pembesaran 2 kali,
kemiringan pi, dan ketinggian 0


# Grafik dengan numerik

$$g(x)= x^2+y^2$$\>function g(x, y) := x^2 + y^2 

\>plot3d("g", -10, 10, -10, 10, distance=3, zoom=1, angle=pi/4, height=0):


![images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_Soal%20Plot%203D-006.png](images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_Soal%20Plot%203D-006.png)

plot 3d dengan ekspresi


$$x^2+y^2$$

akan membentuk grafik tersebut skala sumbu -10, 10, -10, 10 dengan
jarak 3, pembesaran 1 kali, kemiringan pi/4, dan ketinggian 0


# Grafik dengan simbolik

$$h(x)=xsin(x) + cos(y)$$\>function h(x,y):= x\*sin(x)+cos(y)

\>plot3d("h", -10, 10, -10, 10, distance=3, zoom=1, angle=pi, height=0):


![images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_Soal%20Plot%203D-009.png](images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_Soal%20Plot%203D-009.png)

plot 3d dengan ekspresi


$$h(x)=xsin(x) + cos(y)$$akan membentuk grafik tersebut skala sumbu -10, 10, -10, 10 dengan
jarak 3, pembesaran 1 kali, kemiringan pi, dan ketinggian 0


# Menggambar Data x, y, z ruang 3D dengan menggambar titik di dalamnya

\>n=500; ...  
\>    plot3d(normal(2,n),normal(2,n),normal(2,n),points=true,style="+"):


![images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_Soal%20Plot%203D-011.png](images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_Soal%20Plot%203D-011.png)

Fungsi ini menghasilkan vektor dari 500 titik acak yang diambil dari
distribusi normal dengan rata-rata 0 dan standar deviasi 1. Distribusi
normal menghasilkan angka acak yang tersebar dalam bentuk lonceng
(bell curve) dengan sebagian besar angka mendekati nol, tetapi
beberapa angka bisa lebih besar atau lebih kecil.


# Grafik interaktif latex: x^4+6y^3

\>plot3d("exp(-x^4+6\*y^3)",\>user, ...  
\>    title="Turn with the vector keys (press return to finish)"):


![images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_Soal%20Plot%203D-012.png](images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_Soal%20Plot%203D-012.png)

plot interaktif menggunakan user untuk bisa mengubah sudut pandang
yang ada sesuai keinginan sehingga tekan enter untuk mengimport
gambarnya


# Grafik Implisit

\>plot3d("x^2+y^2+4\*x\*z+z^3",\>implicit,r=2,zoom=2.5):


![images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_Soal%20Plot%203D-013.png](images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_Soal%20Plot%203D-013.png)

$$x^2+y^2+4xz^3$$

Grafik implisit dengan 3 variabel ditambahankan "implisit" dengan
skala grafik 2 dan pembesaran 2.5 kali


# Menggambar tampilan, warna dan sudut pandang serta kontur

\>plot3d("exp(x^2\*y)",angle=100°,\>contour,color=green):


![images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_Soal%20Plot%203D-015.png](images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_Soal%20Plot%203D-015.png)

$$x^2y$$Kita bisa mengatur sudut pandang dengan angle contohnya 100, serta
diberi kontur yang isinya warna hijau


# Grafik anaglitif latex: 2x^6+2y^2

\> plot3d("2\*x^6+2\*y^2",\>anaglyph,\>contour,angle=30°):


![images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_Soal%20Plot%203D-017.png](images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_Soal%20Plot%203D-017.png)

EMT dapat memunculkan anaglitif juga yang bisa dilihat dengan kacamata
merah/cyan


# Membuat grafik batang

\>x=-1:0.1:1; y=x'; z=x^2+y^2;

\>xa=(x|1.1)-0.05; ya=(y\_1.1)-0.05;


\>plot3d(xa,ya,z,bar=true):


![images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_Soal%20Plot%203D-018.png](images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_Soal%20Plot%203D-018.png)

\>plot2d("(x^2+y^2-1)^3-x^2\*y^3",r=1.3, ...  
\>  
kita tentukan dulu bentuk grafiknya dengan nilai x y z dan berikan
skala yang ada


# Permukaan benda putar

\>style=".",color=blue,<outline, ...  
\>   level=[-1;0],n=250):


![images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_Soal%20Plot%203D-019.png](images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_Soal%20Plot%203D-019.png)

style . dengan warna biru dan di beri outline


level=[-1;0]: Menunjukkan bahwa plot akan menampilkan nilai dalam
rentang dari -1 hingga 0, kemungkinan merujuk pada nilai z atau
tingkat ketinggian dari objek yang diplot dalam ruang 3D.


# Grafik Povray

\>load povray;

\>defaultpovray="C:\\Program Files\\POV-Ray\\v3.7\\bin\\pvengine.exe"


    C:\Program Files\POV-Ray\v3.7\bin\pvengine.exe

\>pov3d("-x^4+2\*y^2",zoom=3,angle=pi/2);


![images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_Soal%20Plot%203D-020.png](images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_Soal%20Plot%203D-020.png)

povray akan menghasilkan bentuk yang lebih bagus seperti 3d nyata
dengan memasukkan load povray yang harus di install terlebih dahulu
dengan rumus


$$-x^4+2y^2$$pembesaran 3 kali dan kemiringan pi/2


\>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               


    

<pre class="udf">    
    
    
    endfunction
</pre>
    Wrong argument.
    Cannot use a string here.
    
    f3dimplicit:
        solidhuecontour((W-xm)*ff,(y-ym)*ff,(z'-zm)*ff,0,(x[#]-xm)*ff ...
    Try "trace errors" to inspect local variables after errors.
    plot3d:
        =contourcolor,=contourwidth);

    Commands must be separated by semicolon or comma!
    Found: ’; plot3d(r*cos(t)*sin(s),r*cos(t)*cos(s),r*sin(t), &gt;hue,&lt;frame,color=red,zoom=4,amb=0,max=0.7,grid=12,height=50°): (character -110)
    You can disable this in the Options menu.
    Error in:
    ... e(-pi/2,pi/2,100); r=f(t); s=linspace(pi,2pi,100)’; plot3d(r*c ...
                                                         ^

    Commands must be separated by semicolon or comma!
    Found: ’; x=cos(s)*cos(t); y=cos(s)*sin(t); z=sin(s); plot3d(x,y,z,&gt;hue, color=blue,&lt;frame,grid=[10,20], values=s,contourcolor=red,level=[90°-24°;90°-22°], scale=1.4,height=50°): (character -110)
    You can disable this in the Options menu.
    Error in:
    t=linspace(0,2pi,180); s=linspace(-pi/2,pi/2,90)’; x=cos(s)*co ...
                                                    ^

\>t=-1:0.1:1; s=(-1:0.1:1)’; plot3d(t,s,t\*s,grid=10):


    Commands must be separated by semicolon or comma!
    Found: ’; plot3d(t,s,t*s,grid=10): (character -110)
    You can disable this in the Options menu.
    Error in:
    t=-1:0.1:1; s=(-1:0.1:1)’; plot3d(t,s,t*s,grid=10): ...
                            ^

\>n=500; ...  
\>    plot3d(normal(1,n),normal(1,n),normal(1,n),points=true,style="."):


