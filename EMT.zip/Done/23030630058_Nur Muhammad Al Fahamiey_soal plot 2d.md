﻿# 23030630058_Nur Muhammad Al Fahamiey_soal plot 2d
## Contoh soal Plot 2d

# Menggambar Grafik Fungsi Satu Variabel dalam Bentuk Ekspresi

Langsung


\>plot2d("x^2 - 4\*x + 3"):


![images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_soal%20plot%202d-001.png](images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_soal%20plot%202d-001.png)

Ekspresi tunggal dalam “x” (misalnya “x^2 - 4*x + 3 pada soal) atau
nama fungsi (misalnya “f”) menghasilkan grafik fungsi.


# Menggambar Grafik Fungsi Satu Variabel yang Rumusnya Disimpan dalam

Variabel Ekspresi


\>function f(x):= sin(x);

\> plot2d("f", 0, 2pi):


![images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_soal%20plot%202d-002.png](images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_soal%20plot%202d-002.png)

Menyimpan suatu perintah lalu dipanggil kembali saat menggunakannya
seperti memanggil fungsi yang ada untuk dijadikan suatu plot


# Menggambar Grafik Fungsi Satu Variabel yang Fungsinya Didefinisikan

sebagai Fungsi Numerik


\>function f(x) := 1/x

\>plot2d("f"):


![images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_soal%20plot%202d-003.png](images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_soal%20plot%202d-003.png)

Disini tampak fungsi yang ada terdapat variabel yang bersifat numerik
karena terdapat operasi hitung pada variabel


# Menggambar Grafik Fungsi Satu Variabel yang Fungsinya Didefinisikan

sebagai Fungsi Simbolik


\>function g(x) := exp(x); 

\>plot2d("g"):


![images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_soal%20plot%202d-004.png](images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_soal%20plot%202d-004.png)

disini kita memberikan suatu simbol untuk suatu fungsi yang berisi
perintah fungsi, nantinya akan bisa dipanggil layaknya fungsi biasa


# Menggambar Beberapa Kurva Sekaligus

\>plot2d("cos(x)", "sin(x)", [0, 2\*pi]):


![images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_soal%20plot%202d-005.png](images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_soal%20plot%202d-005.png)

Kita juga bisa menggambarkan beberapa fungsi sekaligus dengan cara
memberikan koma dan "..." pada fungsi yang akan kita gunakan


# Menggambar Beberapa Kurva dalam Satu Bidang Koordinat

\>plot2d("x^2", "x^3", [-2, 2]):


![images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_soal%20plot%202d-006.png](images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_soal%20plot%202d-006.png)

sama halnya ini juga menggambarkan beberapa kurva dengan ".." dan koma
sebagai pemisah dengan batasan yang ada


# Menuliskan Label Sumbu Koordinat, Label Kurva, dan Keterangan Kurva

(Legend)


\>plot2d("exp(x)",-1,1);

\>textcolor(black); // set the text color to black

\>title(latex("y=e^x")); // title above the plot

\>xlabel(latex("x")); // "x" for x-axis

\>ylabel(latex("y"),\>vertical); // vertical "y" for y-axis

\>label(latex("(0,1)"),0,1,color=blue): // label a point


![images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_soal%20plot%202d-007.png](images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_soal%20plot%202d-007.png)

kita juga bisa memberikan nama pada grafik kita dengan


&gt;textcolor() untuk memberikan warna teks


&gt;title() untuk memberikan judul grafik


&gt;xlabel() untuk memberikan teks pada ordinat


&gt;ylabel() untuk memberikan teks pada absis


&gt;label(latex("(x,y)"),color=...) untuk memberikan garis perpotongan


# Mengatur Ukuran Gambar, Format (Style), dan Warna Kurva

\>plot2d("log(x)", color=[red]):


![images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_soal%20plot%202d-008.png](images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_soal%20plot%202d-008.png)

kita juga memberikan bentuk lain garis dengan style"..." atau warna
yang diinginkan


# Menggambar Sekumpulan Kurva dengan Satu Perintah plot2d

\>aspect();

\>figure(3,3); ...  
\>    figure(1); plot2d("x^2-x",grid=0); ... // no grid, frame or axis

\> figure(2); plot2d("x",grid=1); ... // x-y-axis

\> figure(3); plot2d("x^3",grid=2); ... // default ticks

\>figure(0):


![images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_soal%20plot%202d-009.png](images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_soal%20plot%202d-009.png)

untuk memberikan beberapa grafik sekaligus kita bisa menggunakan
figure() untuk ukurannya dan urutan 1 hingga n untuk setiap grafik


# Membuat Gambar Kurva yang Bersifat Interaktif

\>plot2d({{"x^2-a\*x",a=1}},\>user,title="Press any key!"):


![images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_soal%20plot%202d-010.png](images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_soal%20plot%202d-010.png)

penggunaan user bisa dilakukan untuk memberikan pengguna bisa
berinteraksi secara langsung pada grafik yang dibuat


# Menggambar Kurva Fungsi Parametrik

\>t=linspace(0,1,1000); ...  
\>   plot2d(t\*cos(8\*pi\*t),t\*sin(4\*pi\*t),r=1):


![images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_soal%20plot%202d-011.png](images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_soal%20plot%202d-011.png)

Grafik parametrik juga bisa untuk memberikan gambaran dalam rentang
suatu grafik dengan t parametrik


# Menggambar Kurva Fungsi Implisit

\>aspect(2);

\>plot2d("x^3+y^2\*y-x",r=2,level=0,contourcolor=red):


![images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_soal%20plot%202d-012.png](images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_soal%20plot%202d-012.png)

\>t=linspace(0,2pi,1000); ...  
\>   plot2d(exp(I\*t)+exp(8\*I\*t),r=4):


![images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_soal%20plot%202d-013.png](images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_soal%20plot%202d-013.png)

Kita juga bisa membuat grafik implisit dengan beberapa variabel di
dalamnya


# Menggambar Daerah Yang Dibatasi Kurva

\>t=linspace(0,2pi,6); ...  
\>   plot2d(sec(t),sin(t),\>filled,style="/",fillcolor=red,r=1.2):


![images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_soal%20plot%202d-014.png](images/23030630058_Nur%20Muhammad%20Al%20Fahamiey_soal%20plot%202d-014.png)

Untuk memberikan daerah luasan kita bisa memberikan isi pada kurva
yang dibuat juga


\>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 


<pre class="udf">    
</pre>
\>                


